﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OperSemp.Forms
{
    public partial class VerAuditoriaMNLForm : Form
    {
        public VerAuditoriaMNLForm()
        {
            InitializeComponent();
        }
    }
}
