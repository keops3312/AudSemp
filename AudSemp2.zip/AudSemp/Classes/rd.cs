﻿

namespace AudSemp.Classes
{
    public class rd
    {
        public string categoria { get; set; }
    }
}
