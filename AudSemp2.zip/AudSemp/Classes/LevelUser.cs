﻿

namespace AudSemp.Classes
{
   
    public class LevelUser
    {
      
        public string level { get; set; }
        

    }
}
