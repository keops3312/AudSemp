﻿

namespace AudSemp.Classes
{
    #region Libraries (librerias)
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    #endregion

    public class ModoOrdenes
    {
        #region Attributes (atributos)
        public string modo { get; set; }
        #endregion
    }
}
