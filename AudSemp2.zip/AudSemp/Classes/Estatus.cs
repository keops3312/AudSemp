﻿

namespace AudSemp.Classes
{
   public class Estatus
    {
    public string estatu { get; set; }
    }
}
