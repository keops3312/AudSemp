﻿
namespace AudSemp.Classes
{
 
    public class categorias
    {
        public string categoria { get; set; }
    }
}
