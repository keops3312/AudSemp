﻿

namespace AudSemp.Classes
{


    public class TiposOrden
    {
        
        public string tipo { get; set; }
     
    }
}
